<?php
$name='DejaVuSerif-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 939.0,
  'Descent' => -236.0,
  'CapHeight' => 939.0,
  'Flags' => 262212,
  'FontBBox' => '[-906 -389 1925 1145]',
  'ItalicAngle' => -11.0,
  'StemV' => 165.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile= __DIR__ . '/DejaVuSerif-BoldItalic.ttf';
$originalsize=347460;
$fontkey='dejavu-bolditalic';
?>