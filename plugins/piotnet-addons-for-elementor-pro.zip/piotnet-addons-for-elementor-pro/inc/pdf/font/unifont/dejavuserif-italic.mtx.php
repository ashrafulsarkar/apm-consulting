<?php
$name='DejaVuSerif-Italic';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 68,
  'FontBBox' => '[-839 -347 1645 1109]',
  'ItalicAngle' => -11.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile= __DIR__ . '/DejaVuSerif-Italic.ttf';
$originalsize=345996;
$fontkey='dejavuitalic';
?>