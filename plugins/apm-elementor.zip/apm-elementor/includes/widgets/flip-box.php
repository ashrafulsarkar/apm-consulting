<?php
namespace APM_Elementor_Addon;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class APM_Flip_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return 'apm-flip-box';
	}

	public function get_title() {
		return esc_html__( 'APM Flip Box', 'apmelementor' );
	}

	public function get_icon() {
		return 'eicon-flip-box';
	}

	public function get_categories() {
		return [ 'apm' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_side_a_content',
			[ 
				'label' => esc_html__( 'Front', 'apmelementor' ),
			]
		);

		$this->add_control(
			'selected_icon',
			[ 
				'label'            => esc_html__( 'Icon', 'apmelementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => [ 
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'title_text_a',
			[ 
				'label'       => esc_html__( 'Title', 'apmelementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'This is the heading', 'apmelementor' ),
				'placeholder' => esc_html__( 'Enter your title', 'apmelementor' ),
				'dynamic'     => [ 
					'active' => true,
				],
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_side_b_content',
			[ 
				'label' => esc_html__( 'Back', 'apmelementor' ),
			]
		);

		$this->add_control(
			'title_text_b',
			[ 
				'label'       => esc_html__( 'Title', 'apmelementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'This is the heading', 'apmelementor' ),
				'placeholder' => esc_html__( 'Enter your title', 'apmelementor' ),
				'dynamic'     => [ 
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'description_text_b',
			[ 
				'label'       => esc_html__( 'Description', 'apmelementor' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipiscing elit dolor', 'apmelementor' ),
				'placeholder' => esc_html__( 'Enter your description', 'apmelementor' ),
				'dynamic'     => [ 
					'active' => true,
				],
				'rows'        => 10,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_box_settings',
			[ 
				'label' => esc_html__( 'Settings', 'apmelementor' ),
			]
		);

		$this->add_control(
			'border_radius',
			[ 
				'label'      => esc_html__( 'Border Radius', 'apmelementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [ 
					'px'  => [ 
						'max' => 200,
					],
					'em'  => [ 
						'max' => 20,
					],
					'rem' => [ 
						'max' => 20,
					],
				],
				'default'    => [ 
					'size'    => 16,
					'unit'   => 'px',
				],
				'separator'  => 'after',
				'selectors'  => [ 
					'{{WRAPPER}} .apm-flip-box__layer' => 'border-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_a',
			[ 
				'label' => esc_html__( 'Front', 'apmelementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'front_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'apmelementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#F7F7F7',
				'selectors' => [
					'{{WRAPPER}} .apm-flip-box__front' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_a',
			[ 
				'label'      => esc_html__( 'Padding', 'apmelementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [ 
					'top'    => 40,
					'right'  => 32,
					'bottom' => 40,
					'left'   => 32,
					'unit'   => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm-flip-box__front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'alignment_a',
			[ 
				'label'     => esc_html__( 'Alignment', 'apmelementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [ 
					'left'   => [ 
						'title' => esc_html__( 'Left', 'apmelementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [ 
						'title' => esc_html__( 'Center', 'apmelementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [ 
						'title' => esc_html__( 'Right', 'apmelementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [ 
					'{{WRAPPER}} .apm-flip-box__front' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'heading_icon_style',
			[ 
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Icon', 'apmelementor' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_spacing',
			[ 
				'label'      => esc_html__( 'Spacing', 'apmelementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [ 
					'px'  => [ 
						'max' => 100,
					],
					'em'  => [ 
						'max' => 10,
					],
					'rem' => [ 
						'max' => 10,
					],
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm-icon-wrapper' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_size',
			[ 
				'label'      => esc_html__( 'Icon Size', 'apmelementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [ 
					'px'  => [ 
						'min' => 6,
						'max' => 300,
					],
					'em'  => [ 
						'min' => 0.6,
						'max' => 30,
					],
					'rem' => [ 
						'min' => 0.6,
						'max' => 30,
					],
				],
				'selectors'  => [ 
					'{{WRAPPER}} .elementor-icon'     => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'heading_title_style_a',
			[ 
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Title', 'apmelementor' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color_a',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ 
					'{{WRAPPER}} .apm-flip-box__front .apm-flip-box__layer__title' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[ 
				'name'      => 'title_typography_a',
				'global'    => [ 
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .apm-flip-box__front .apm-flip-box__layer__title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_b',
			[ 
				'label' => esc_html__( 'Back', 'apmelementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'back_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'apmelementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#333333',
				'selectors' => [
					'{{WRAPPER}} .apm-flip-box__back' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_b',
			[ 
				'label'      => esc_html__( 'Padding', 'apmelementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [ 
					'top'    => 32,
					'right'  => 32,
					'bottom' => 32,
					'left'   => 32,
					'unit'   => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm-flip-box__back' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'alignment_b',
			[ 
				'label'     => esc_html__( 'Alignment', 'apmelementor' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [ 
					'left'   => [ 
						'title' => esc_html__( 'Left', 'apmelementor' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [ 
						'title' => esc_html__( 'Center', 'apmelementor' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [ 
						'title' => esc_html__( 'Right', 'apmelementor' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [ 
					'{{WRAPPER}} .apm-flip-box__back' => 'text-align: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'heading_title_style_b',
			[ 
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Title', 'apmelementor' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color_b',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ 
					'{{WRAPPER}} .apm-flip-box__back .apm-flip-box__layer__title' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[ 
				'name'      => 'title_typography_b',
				'global'    => [ 
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .apm-flip-box__back .apm-flip-box__layer__title',
			]
		);

		$this->add_control(
			'heading_description_style_b',
			[ 
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Description', 'apmelementor' ),
				'separator' => 'before',
			]
		);

		$this->add_control(
			'description_color_b',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ 
					'{{WRAPPER}} .apm-flip-box__back .apm-flip-box__layer__description' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[ 
				'name'      => 'description_typography_b',
				'global'    => [ 
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .apm-flip-box__back .apm-flip-box__layer__description',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings          = $this->get_settings_for_display();
		$migration_allowed = Icons_Manager::is_migration_allowed();

		if ( ! isset( $settings['icon'] ) && ! $migration_allowed ) {
			// add old default
			$settings['icon'] = 'fa fa-star';
		}

		if ( ! empty( $settings['icon'] ) ) {
			$this->add_render_attribute( 'icon', 'class', $settings['icon'] );
		}

		$has_icon = ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon'] );
		$migrated = isset( $settings['__fa4_migrated']['selected_icon'] );
		$is_new   = empty( $settings['icon'] ) && $migration_allowed;

		?>
		<div class="apm-flip-box" tabindex="0">
			<div class="apm-flip-box__layer apm-flip-box__front">
				<div class="apm-flip-box__layer__inner">
					<?php if ( $has_icon ) : ?>
						<div class="apm-icon-wrapper">
							<div class="elementor-icon">
								<?php if ( $is_new || $migrated ) :
									Icons_Manager::render_icon( $settings['selected_icon'] );
								else : ?>
									<i <?php $this->print_render_attribute_string( 'icon' ); ?>></i>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $settings['title_text_a'] ) ) : ?>
						<h5 class="apm-flip-box__layer__title">
							<?php $this->print_unescaped_setting( 'title_text_a' ); ?>
						</h5>
					<?php endif; ?>
					<div class="apm_front_btn">
						<span><i class="fa-solid fa-plus"></i></span>
					</div>
				</div>
			</div>
			<div class="apm-flip-box__layer apm-flip-box__back" style="display:none">
				<div class="apm-flip-box__layer__inner">
					<?php if ( ! empty( $settings['title_text_b'] ) ) : ?>
						<h5 class="apm-flip-box__layer__title">
							<?php $this->print_unescaped_setting( 'title_text_b' ); ?>
						</h5>
					<?php endif; ?>

					<?php if ( ! empty( $settings['description_text_b'] ) ) : ?>
						<div class="apm-flip-box__layer__description">
							<?php $this->print_unescaped_setting( 'description_text_b' ); ?>
						</div>
					<?php endif; ?>
					<div class="apm_back_btn">
						<span><i class="fa-solid fa-plus"></i></span>
					</div>
				</div>
			</div>
			<script>
				; (function ($) {
					$('.apm_front_btn span').on('click', ()=>{
						$('.apm-flip-box__front').css('display', 'none');
						$('.apm-flip-box__back').css('display', 'block');
					})
					$('.apm_back_btn span').on('click', ()=>{
						$('.apm-flip-box__front').css('display', 'block');
						$('.apm-flip-box__back').css('display', 'none');
					})
				})(jQuery);

			</script>
		</div>
		<?php
	}

	/**
	 * Render Flip Box widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	protected function content_template() {
	}
}
