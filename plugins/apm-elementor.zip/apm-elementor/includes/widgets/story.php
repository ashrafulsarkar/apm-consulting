<?php
namespace APM_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor icon list widget.
 *
 * Elementor widget that displays a bullet list with any chosen icons and texts.
 *
 * @since 1.0.0
 */
class APM_Story extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve icon list widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'apm-story';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve image list widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'APM Story Slider', 'apmelementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon list widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-carousel';
	}

	public function get_categories() {
		return [ 'apm' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'story', 'apm', 'slider' ];
	}

	/**
	 * Register icon list widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'section_story',
			[ 
				'label' => esc_html__( 'Story Items', 'apmelementor' ),
			]
		);


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'year',
			[
				'label' => esc_html__( 'Year', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '2024' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'apmsystem2 neues Branchenmodul Blech' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'story',
			[
				'label' => esc_html__( 'Story List', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'name' => esc_html__( 'Year #1', 'textdomain' ),
						'content' => esc_html__( 'apmsystem2 neues Branchenmodul Blech', 'textdomain' ),
					],
					[
						'name' => esc_html__( 'Year #2', 'textdomain' ),
						'content' => esc_html__( 'apmsystem2 neues Branchenmodul Blech', 'textdomain' ),
					],
				],
				'title_field' => '{{{ year }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_timeline',
			[ 
				'label' => esc_html__( 'Timeline', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'timeline_color',
			[ 
				'label'     => esc_html__( 'Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => [ 
					'{{WRAPPER}} .apm_timeline span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'timeline_active_color',
			[ 
				'label'     => esc_html__( 'Active Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#BD1C00',
				'selectors' => [
					'{{WRAPPER}} .apm_timeline span.slick-current.slick-active' => 'color: {{VALUE}}',
					'{{WRAPPER}} .apm_timeline span.slick-current.slick-active::after' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'timeline_typography',
				'selector' => '{{WRAPPER}} .apm_timeline span',
			]
		);

		$this->add_control(
			'timeline_show',
			[ 
				'label'      => esc_html__( 'Show', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 10,
					],
				],
				'default'    => [ 
					'size' => 3,
				],
			]
		);

		$this->add_responsive_control(
			'timeline_point',
			[ 
				'label'      => esc_html__( 'Circle Space', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [ 
					'size' => 40,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .apm_timeline span::after' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_Tame',
			[ 
				'label' => esc_html__( 'Title', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => [ 
					'{{WRAPPER}} .apm_story_content h3' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .apm_story_content h3',
			]
		);
		$this->add_responsive_control(
			'title_align',
			[
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .apm_story_content h3' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_year',
			[ 
				'label' => esc_html__( 'Year', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'year_color',
			[ 
				'label'     => esc_html__( 'Year', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#E6E6E6',
				'selectors' => [
					'{{WRAPPER}} .apm_story_year span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'year_active_color',
			[ 
				'label'     => esc_html__( 'Active Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#BD1C00',
				'selectors' => [
					'{{WRAPPER}} .apm_story_year span.slick-center' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'year_typography',
				'selector' => '{{WRAPPER}} .apm_story_year span',
			]
		);

		$this->add_responsive_control(
			'year_space',
			[ 
				'label'      => esc_html__( 'Space', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 120,
					],
				],
				'default'    => [ 
					'size' => 37,
					'unit' => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm_story_year span' => 'padding-top: {{SIZE}}{{UNIT}};padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$id       = $this->get_id();
		$total_items = count( $settings['story'] );
		if ( $settings['story'] ) { ?>
				<div class="apm_timeline" id="apm_timeline_active_<?php echo $id;?>">
					<?php foreach ( $settings['story'] as $item ) { ?>
						<span><?php echo $item['year'];?></span>
					<?php }	?>
				</div>
				<div class="apm_story">
					<div class="apm_story_content" id="apm_story_content_active_<?php echo $id;?>">
						<?php foreach (  $settings['story'] as $item ) { ?>
							<div class="apm_story_title">
								<h3><?php echo $item['title'];?></h3>
							</div>
						<?php } ?>
					</div>
					<div class="apm_story_year" id="apm_story_year_active_<?php echo $id;?>" style="background-image: url(<?php echo plugins_url( 'assets/icons/story.svg', plugin_dir_path( __DIR__ ) ); ?>);">
						<?php foreach (  $settings['story'] as $item ) { ?>
							<span><?php echo $item['year'];?></span>
						<?php } ?>
					</div>
				</div>
		<?php } ?>
		<script>
			; (function ($) {
				$('#apm_story_content_active_<?php echo $id;?>').slick({
					slidesToShow: 1,
					slidesToScroll: 1,
					fade: true,
					infinite:false,
					draggable: false,
					asNavFor: '#apm_story_year_active_<?php echo $id;?>,#apm_timeline_active_<?php echo $id;?>',
					prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-arrow-left-long"></i></button>',
					nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-arrow-right-long"></i></button>',
				});

				$('#apm_timeline_active_<?php echo $id;?>').slick({
					slidesToShow: <?php echo $settings['timeline_show']['size'];?>,
					slidesToScroll: 1,
					arrows: false,
					asNavFor: '#apm_story_content_active_<?php echo $id;?>,#apm_story_year_active_<?php echo $id;?>',
					draggable: false,
					infinite:false,
					focusOnSelect: true,
					responsive: [
						{
							breakpoint: 992,
							settings: {
								slidesToShow: <?php echo $total_items > 7 ? "7" : ($total_items - 1);?>,
							}
						},
						{
							breakpoint: 768,
							settings: {
								slidesToShow: <?php echo $total_items > 5 ? "5" : ($total_items - 1);?>,
							}
						},
						{
							breakpoint: 576,
							settings: {
								slidesToShow: <?php echo $total_items > 4 ? "4" : ($total_items - 1);?>,
							}
						},
					]
				});

				$('#apm_story_year_active_<?php echo $id;?>').slick({
					slidesToShow: 3,
					slidesToScroll: 1,
					asNavFor: '#apm_story_content_active_<?php echo $id;?>',
					arrows: false,
					focusOnSelect: false,
					vertical: true,
    				verticalScrolling: true,
					useTransform: true,
    				cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
					centerMode: true,
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Render icon list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	protected function content_template() { }
}
