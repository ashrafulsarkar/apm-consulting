<?php
namespace APM_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor icon list widget.
 *
 * Elementor widget that displays a bullet list with any chosen icons and texts.
 *
 * @since 1.0.0
 */
class APM_Arrow extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve icon list widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'apm-arrow';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve image list widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'APM Arrow', 'apmelementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon list widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-arrow-right';
	}

	public function get_categories() {
		return [ 'apm' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'arrow', 'apm' ];
	}

	/**
	 * Register icon list widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'section_arrow',
			[ 
				'label' => esc_html__( 'Arrow', 'apmelementor' ),
			]
		);

		$this->add_control(
			'arrow_type',
			[ 
				'label'   => esc_html__( 'Arrow Type', 'apmelementor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'right',
				'options' => [ 
					'left'  => esc_html__( 'Left', 'apmelementor' ),
					'right' => esc_html__( 'Right', 'apmelementor' ),
					'up'    => esc_html__( 'Up', 'apmelementor' ),
					'down'  => esc_html__( 'Down', 'apmelementor' ),
				],
			]
		);

		$this->add_control(
			'website_link',
			[ 
				'label'       => esc_html__( 'Link', 'apmelementor' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'options'     => [ 'url', 'is_external', 'nofollow' ],
				'default'     => [ 
					'url' => '',
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[ 
				'label' => esc_html__( 'Arrow', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_responsive_control(
			'arrow_size',
			[ 
				'label'      => esc_html__( 'Arrow Width', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [ 
					'size' => 52,
					'unit' => 'px',
				],
				'separator'  => 'after',
				'selectors'  => [ 
					'{{WRAPPER}} .apm_arrow a' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'arrow_tabs'
		);

		$this->start_controls_tab(
			'arrow_normal_tab',
			[ 
				'label' => esc_html__( 'Normal', 'apmelementor' ),
			]
		);

		$this->add_control(
			'text_color',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => [ 
					'{{WRAPPER}} .apm_arrow a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background',
			[ 
				'label'     => esc_html__( 'Background', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#E6E6E6',
				'selectors' => [ 
					'{{WRAPPER}} .apm_arrow a' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrow_hover_tab',
			[ 
				'label' => esc_html__( 'Hover', 'apmelementor' ),
			]
		);

		$this->add_control(
			'text_hover_color',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => [ 
					'{{WRAPPER}} .apm_arrow a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_hover',
			[ 
				'label'     => esc_html__( 'Background', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#E6E6E6',
				'selectors' => [ 
					'{{WRAPPER}} .apm_arrow a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'border_radius',
			[ 
				'label'      => esc_html__( 'Border Radius', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [ 
					'top'    => 50,
					'right'  => 50,
					'bottom' => 50,
					'left'   => 50,
					'unit'   => '%',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm_arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'font_size',
			[ 
				'label'      => esc_html__( 'Arrow Size', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 50,
					],
				],
				'default'    => [ 
					'size' => 18,
					'unit' => 'px',
				],
				'separator'  => 'before',
				'selectors'  => [ 
					'{{WRAPPER}} .apm_arrow a i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['website_link']['url'] ) ) {
			$this->add_link_attributes( 'website_link', $settings['website_link'] );
		}
		?>
		<div class="apm_arrow">
			<a <?php $this->print_render_attribute_string( 'website_link' ); ?>>
				<i class="fa-solid fa-arrow-<?php echo $settings['arrow_type']; ?>"></i>
			</a>
		</div>
		<?php
	}

	/**
	 * Render icon list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	protected function content_template() {
	}
}
