<?php
namespace APM_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor icon list widget.
 *
 * Elementor widget that displays a bullet list with any chosen icons and texts.
 *
 * @since 1.0.0
 */
class APM_Testiamonial extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve icon list widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'apm-testiamonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve image list widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'APM Testiamonial', 'apmelementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve icon list widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	public function get_categories() {
		return [ 'apm' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'testiamonial', 'apm', 'slider' ];
	}

	/**
	 * Register icon list widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'section_testiamonial',
			[ 
				'label' => esc_html__( 'Testiamonial Items', 'apmelementor' ),
			]
		);


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			[ 
				'label'   => esc_html__( 'Choose Image', 'apmelementor' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [ 
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'content',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Content' , 'textdomain' ),
				'show_label' => false,
			]
		);

		$repeater->add_control(
			'name',
			[
				'label' => esc_html__( 'Name', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Eric Mangold' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'digination',
			[
				'label' => esc_html__( 'Digination', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Creative Director, Excity Marketing' , 'textdomain' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'testiamonial',
			[
				'label' => esc_html__( 'Testiamonial List', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'name' => esc_html__( 'Name #1', 'textdomain' ),
						'content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
					[
						'name' => esc_html__( 'Name #2', 'textdomain' ),
						'content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		
		$this->start_controls_section(
			'section_style_image',
			[ 
				'label' => esc_html__( 'Image', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[ 
				'label'      => esc_html__( 'Border Radius', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [ 
					'top'    => 16,
					'right'  => 16,
					'bottom' => 16,
					'left'   => 16,
					'unit'   => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm_testiamonial_image img.main' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_contant',
			[ 
				'label' => esc_html__( 'Contant', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'contant_color',
			[ 
				'label'     => esc_html__( 'Contant Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [ 
					'{{WRAPPER}} .apm_testiamonial_content p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'contant_typography',
				'selector' => '{{WRAPPER}} .apm_testiamonial_content p',
			]
		);

		$this->add_responsive_control(
			'content_space',
			[ 
				'label'      => esc_html__( 'Space', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 50,
					],
				],
				'default'    => [ 
					'size' => 16,
					'unit' => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm_testiamonial_content p' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_name',
			[ 
				'label' => esc_html__( 'Name', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_color',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#BD1C00',
				'selectors' => [ 
					'{{WRAPPER}} .apm_testiamonial_content h5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .apm_testiamonial_content .name::before' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .apm_testiamonial_content h5',
			]
		);

		$this->add_control(
			'name_align',
			[
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .apm_testiamonial_content .name' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'name_space',
			[ 
				'label'      => esc_html__( 'Space', 'apmelementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [ 
					'px' => [ 
						'min' => 0,
						'max' => 50,
					],
				],
				'default'    => [ 
					'size' => 13,
					'unit' => 'px',
				],
				'selectors'  => [ 
					'{{WRAPPER}} .apm_testiamonial_content .name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_digination',
			[ 
				'label' => esc_html__( 'Digination', 'apmelementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'digination_color',
			[ 
				'label'     => esc_html__( 'Text Color', 'apmelementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => [ 
					'{{WRAPPER}} .apm_testiamonial_content h6' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[ 
				'name'     => 'digination_typography',
				'selector' => '{{WRAPPER}} .apm_testiamonial_content h6',
			]
		);

		$this->add_control(
			'digination_align',
			[
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .apm_testiamonial_content h6' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$id       = $this->get_id();
		?>
		<div class="apm_testiamonial" id="apm_testiamonial_active_<?php echo $id;?>">
			<?php
			if ( $settings['testiamonial'] ) {
				foreach (  $settings['testiamonial'] as $item ) { ?>
			<div class="apm_testaimonial_part">
				<div class="apm_testiamonial_item">
					<div class="apm_testiamonial_image">
						<img class="svg" src="<?php echo plugins_url( 'assets/icons/rectangle.svg', plugin_dir_path( __DIR__ ) ); ?>">
						<img class="main" src="<?php echo $item['image']['url'];?>" alt="<?php echo $item['name'];?>">
					</div>
					<div class="apm_testiamonial_content">
						<?php echo $item['content'];?>
						<div class="name">
							<h5><?php echo $item['name'];?></h5>
						</div>
						<h6><?php echo $item['digination'];?></h6>
					</div>
				</div>
			</div>
			<?php } } ?>
		</div>
		<script>
			; (function ($) {
				$('#apm_testiamonial_active_<?php echo $id;?>').slick({
					fade: true,
					cssEase: 'linear',
					autoplay: true,
					speed: 500,
					prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-arrow-left"></i></button>',
					nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-arrow-right"></i></button>',
					responsive: [
						{
						breakpoint: 992,
							settings: {
								arrows: false,
								dots: true
							}
						},
					]
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Render icon list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	protected function content_template() { }
}
